function suma(a, b) {
    return a+b;
}

console.log(suma(10,3));