/* Programa para calcular el área de un rectángulo */

{
    const base = 10;
    const altura = 20;
    const area = base * altura;
    {
        console.log(area);
    }
    altura = 15;
    area = base * altura;
    console.log(area);
}
