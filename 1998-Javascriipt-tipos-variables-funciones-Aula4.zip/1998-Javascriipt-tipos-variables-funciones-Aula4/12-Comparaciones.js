const edad = 39;
const edadComoTexto = "39";

console.log(edad === edadComoTexto);
console.log(typeof(edad));
console.log(typeof(edadComoTexto));
console.log(typeof(edad) === typeof(edadComoTexto));