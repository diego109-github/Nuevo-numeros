const edad = 39;

console.log(edadPersona);
