//Inicio de cálculo de tiempo
console.time('Tiempo');
//Mostrando mensajes
console.log('Hola Mundo');

const edad = 39;
console.log(edad);

//Mostrar un error
console.error('Variable debe ser mayor a 10');

//Mostrar una advertencia
console.warn('Debe indicar un valor');

console.timeEnd('Tiempo');