var nombreCompleto = "Leonardo José";
var ciudadDomicilio = 'Buenos Aires';
var fechaNacimiento = "13 de noviembre de 2008";
var diaIndependenciaPais = "19/04/1810";

var fichaTecnicaModo1 = 'Nombre del producto\n\
Código del producto\n\
Valor';

var fichaTecnicaModo2 = 'Modo 2:\n' +
'Nombre del producto\n' +
'Código del producto\n' + 
'Valor';

var fichaTecnicaModo3 = `Modo 3:
Nombre del producto
Codigo del producto
Valor`;


//console.log(nombreCompleto.toLowerCase());
//console.log(ciudadDomicilio.toUpperCase());
console.log(fechaNacimiento);
console.log(fechaNacimiento.length)
console.log(diaIndependenciaPais);
//console.log(fichaTecnicaModo3);