const edad = 39;
let nombre = 'Leonardo';

nombre = 39;
