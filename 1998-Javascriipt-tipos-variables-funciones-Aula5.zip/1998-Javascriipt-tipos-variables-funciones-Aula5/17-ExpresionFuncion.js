console.log(multiplicaNumeros(1,2,3));
console.log(edad);

/*
function multiplicaNumeros(a, b, c) {
    const resultado = a*b*c;
    return resultado;
}
*/
var edad = 39;
const multiplicaNumeros = function(a, b, c) {
    const resultado = a*b*c;
    return resultado;
}




