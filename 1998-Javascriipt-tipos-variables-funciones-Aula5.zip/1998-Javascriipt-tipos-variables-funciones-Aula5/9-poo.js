class Numeros {

    suma(a, b) {
        return a + b;
    }
}

const obj = new Numeros();
console.log(obj.suma(10,3));