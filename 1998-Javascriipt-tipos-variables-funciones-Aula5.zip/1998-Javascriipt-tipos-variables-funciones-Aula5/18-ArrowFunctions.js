function multiplicaNumeros(a, b, c) {
    return a*b*c;
}


//Expresión de función
const multiplicaNumeros = function(a, b, c) {
    return a*b*c;
}

//Arrow Function
const multiplicaNumeroFuncionFlecha = (a, b, c) => a*b*c;

const potenciaDe2 = numero => numero*numero;
