const edadUsuario = 25;
const edadPermitida = 20;

(edadUsuario >= edadPermitida) ? console.log('Venta habilitada') 
                                : console.log('Prohibida la venta');

/*
if (edadUsuario >= edadPermitida) {
    console.log('Venta habilitada');
} else {
    console.log('Prohibida la venta');
}
*/


