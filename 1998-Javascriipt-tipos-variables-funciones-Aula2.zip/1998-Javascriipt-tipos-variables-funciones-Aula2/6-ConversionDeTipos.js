//Conversión implicita
const edad = 39;
const edadUsuario = "39a";

console.log(edad.toString() + edadUsuario);

//Conversión explicita

console.log(100 + edad + Number(edadUsuario));
