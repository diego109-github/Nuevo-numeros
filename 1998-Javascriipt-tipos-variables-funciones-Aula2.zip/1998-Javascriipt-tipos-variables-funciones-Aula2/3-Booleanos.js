//var menorDeEdad = false;
var edadActual = "39";

console.log(edadActual === 39);