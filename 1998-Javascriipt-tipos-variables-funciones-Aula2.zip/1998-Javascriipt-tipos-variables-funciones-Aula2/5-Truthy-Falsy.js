const usuarioConectado = false;
const cuentaDisponible = true;
const cadenaVacia = "a";
const numeroEntero = 100;
let variableNoDefinida;
const variableNula = null;

console.log(typeof variableNula);
console.log(typeof variableNoDefinida);
console.log(typeof numeroEntero);
console.log(typeof cadenaVacia);
console.log(typeof cuentaDisponible);